//
//  Meme.swift
//  Meme2
//
//  Created by Malak Bassam on 11/27/18.
//  Copyright © 2018 Udacity. All rights reserved.
//


import Foundation
import UIKit

struct Meme {
    var  topTextField : String
    var  bottomTextField : String
    var  image: UIImage!
    var  memedImage:UIImage!
}


//
//  MemeSentCollectionViewCell.swift
//  Meme2
//
//  Created by Malak Bassam on 11/27/18.
//  Copyright © 2018 Udacity. All rights reserved.
//

import UIKit

class MemeSentCollectionViewCell: UICollectionViewCell {
     @IBOutlet weak var memeImageView: UIImageView!
}
